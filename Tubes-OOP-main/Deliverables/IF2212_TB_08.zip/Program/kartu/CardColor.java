/*
 * Enum Warna Kartu
 */

package kartu;

public enum CardColor {
    MERAH,
    HIJAU,
    KUNING,
    BIRU,
    WILD;
}
