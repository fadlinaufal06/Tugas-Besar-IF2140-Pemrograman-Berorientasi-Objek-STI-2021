# Tubes-OOP
Tugas besar mata kuliah Pemrograman Berorientasi Objek STI Kelompok 08

## Cara run:
```
$ javac Main.java
$ java Main
```